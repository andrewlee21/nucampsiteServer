module.exports = {
  secretKey: "12345-67890-09876-54321",
  mongoUrl: "mongodb://localhost:27017/nucampsite",
  facebook: {
    clientId: "5412923328749447",
    clientSecret: "07506bb1837a483229d67248ee1df07a",
  },
};
